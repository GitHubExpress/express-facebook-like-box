=== Express Facebook LikeBox ===
Contributors: unicoder
Tags: facebook, facebook like, facebook like box, like box
Requires at least: 4.7.3
Tested up to: 4.7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is custom made WordPress widget plugin for Facebook LikeBox.

== Description ==
A few notes about the sections above:

*   "Contributors" unicoder
*   "Tags" facebook, facebook like, facebook like box, like box
*   "Requires at least" 4.7.4
*   "Tested up to" 4.7.4 is the highest version that you've *successfully used to test the plugin*. Note that it might work on higher versions... this is just the highest one you've verified.


== Installation ==

1. Upload `express-facebook-like-box` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. You will find a widget "Express Facebook LikeBox". Just use as a Widget


== Screenshots ==

1.`/assets/screenshot-1.png`
2.`/assets/screenshot-2.png`
3.`/assets/screenshot-3.png`
4.`/assets/screenshot-4.png`
5.`/assets/screenshot-5.png`
6.`/assets/screenshot-6.png`


== Changelog ==
= 1.0.0 =
* A change since the previous version.





Features:
1. Facebook Likebox with various options.